<div class="wps-header-banner"><div class="wps-header-icon"></div></div>
