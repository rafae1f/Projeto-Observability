<div style = "text-align: left;">Hello, Here is the statistical report for your website:</div>
<ul>
 	<li>Online Users: <strong>[wpstatistics stat=usersonline format=english]</strong></li>
 	<li>Today's Visitors: <strong>[wpstatistics stat=visitors time=today format=english]</strong></li>
 	<li>Today's Visits: <strong>[wpstatistics stat=visits time=today format=english]</strong></li>
 	<li>Yesterday's Visitors: <strong>[wpstatistics stat=visitors time=yesterday format=english]</strong></li>
 	<li>Yesterday's Visits: <strong>[wpstatistics stat=visits time=yesterday format=english]</strong></li>
 	<li>Total Visitors: <strong>[wpstatistics stat=visitors time=total format=english]</strong></li>
 	<li>Total Visits: <strong>[wpstatistics stat=visits time=total format=english]</strong></li>
</ul>
<div></div>
<div>Thank you for using WP Statistics!</div>